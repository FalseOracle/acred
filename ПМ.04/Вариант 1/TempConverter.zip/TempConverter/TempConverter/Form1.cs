﻿using System;
using System.Globalization;
using System.Windows.Forms;

namespace TempConverter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnConvert_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBoxCelsius.Text))
            {
                MessageBox.Show("Введите значение температуры в градусах Цельсия.",
                    "Ошибка ввода",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                return;
            }

            double celsius;

            if (!double.TryParse(textBoxCelsius.Text.Replace(',', '.'),
                                 NumberStyles.Float,
                                 CultureInfo.InvariantCulture,
                                 out celsius))
            {
                MessageBox.Show("Некорректный формат числа. Введите число, например: 36.6",
                    "Ошибка ввода",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                return;
            }

            double fahrenheit = celsius * 9.0 / 5.0 + 32.0;

            labelResult.Text = fahrenheit.ToString("F1", CultureInfo.InvariantCulture);
        }
    }
}
